//
//  AppDelegate.h
//  MyCalculator
//
//  Created by daniel on 1/27/15.
//  Copyright (c) 2015 daniel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

