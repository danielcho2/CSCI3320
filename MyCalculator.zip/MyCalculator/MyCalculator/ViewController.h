//
//  ViewController.h
//  MyCalculator
//
//  Created by daniel on 1/27/15.
//  Copyright (c) 2015 daniel. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *display;

@end

