//
//  ViewController.m
//  Calculator
//
//  Created by Jenna Tsedensodnom on 2/1/15.
//  Copyright (c) 2015 Jenna Tsedensodnom. All rights reserved.
//

#import "ViewController.h"
#import "CalculatorBrain.h"

@interface ViewController ()
@property (nonatomic) BOOL userIsInTheMiddleOfEnteringANumber;
@property (nonatomic, strong) CalculatorBrain *brain;
@property (nonatomic,strong) NSDictionary *testVariableValues;
@end

@implementation ViewController

@synthesize brain = _brain;
@synthesize display = _display;
@synthesize brainDisplay = _barinDisplay;
@synthesize variablesDisplay = _variablesDisplay;
@synthesize testVariableValues=_testVariableValues;

- (NSDictionary *)testVariableValues{
    if(!_testVariableValues) _testVariableValues=[[NSDictionary alloc]init];
    return _testVariableValues;
}



- (CalculatorBrain *)brain
{
    if(!_brain) _brain = [[CalculatorBrain alloc] init];
    return _brain;
}


- (IBAction)dgitPressed:(UIButton *)sender {
    
    NSString *digit = [sender currentTitle];
    if (self.userIsInTheMiddleOfEnteringANumber){
 
    self.display.text = [self.display.text stringByAppendingString: digit];

    } else {
        self.display.text = digit;
        self.userIsInTheMiddleOfEnteringANumber = YES;
    }
}


- (IBAction)enterPressed
{
    [self.brain pushOperand:[self.display.text doubleValue]];
    self.userIsInTheMiddleOfEnteringANumber = NO;
    self.brainDisplay.text = [self.brainDisplay.text stringByAppendingString:self.display.text];
    self.brainDisplay.text = [self.brainDisplay.text stringByAppendingString:@" "];
    
}


- (IBAction)variablePressed:(UIButton *)sender {

    if (self.userIsInTheMiddleOfEnteringANumber) {
        [self enterPressed];
        
    }
    [self.brain pushVariable:sender.currentTitle];
    self.display.text = sender.currentTitle;
    
   
}



- (IBAction)operationPressed:(UIButton *)sender
{
    if (self.userIsInTheMiddleOfEnteringANumber){
        [self enterPressed];
    }
    NSString *operation = [sender currentTitle];
    double result = [self.brain performOperation:operation];
    self.display.text = [NSString stringWithFormat:@"%g", result];
 
    self.brainDisplay.text = [self.brainDisplay.text stringByAppendingString: operation];
    self.brainDisplay.text = [self.brainDisplay.text stringByAppendingString:@"= "];

}

- (IBAction)testPressed:(UIButton *)sender {
   
    if ([sender.currentTitle isEqualToString:@"test 1"]){
        self.testVariableValues = [NSDictionary dictionaryWithObjectsAndKeys:@"5",@"x",@"4.8",@"y",@"10",@"foo", nil];
    }
    
    if ([sender.currentTitle isEqualToString:@"test 2"]){
        self.testVariableValues = [NSDictionary dictionaryWithObjectsAndKeys:@"-5",@"x",@"-4.8",@"y",@"-10",@"foo", nil];
    }

    if ([sender.currentTitle isEqualToString:@"test 3"]){
        self.testVariableValues = nil;
    }

    
    self.variablesDisplay.text=nil;
    NSSet *usedVariablesSet=[CalculatorBrain variablesUsedInProgram:self.brain.program];
    NSArray *variablesUsedArray = [usedVariablesSet allObjects];
    if ([self.testVariableValues count]>0) {
        for (int i=0; i<[variablesUsedArray count]; i++) {
            if (!self.variablesDisplay.text) {
                self.variablesDisplay.text=[variablesUsedArray objectAtIndex:i];
                self.variablesDisplay.text=[self.variablesDisplay.text stringByAppendingString:@"="];
                self.variablesDisplay.text=[self.variablesDisplay.text stringByAppendingString:[self.testVariableValues valueForKey:[variablesUsedArray objectAtIndex:i]]];
                self.variablesDisplay.text=[self.variablesDisplay.text stringByAppendingString:@"  "];
            }
            else {
                self.variablesDisplay.text=[self.variablesDisplay.text stringByAppendingString:[variablesUsedArray objectAtIndex:i]];
                self.variablesDisplay.text=[self.variablesDisplay.text stringByAppendingString:@"="];
                self.variablesDisplay.text=[self.variablesDisplay.text stringByAppendingString:[self.testVariableValues valueForKey:[variablesUsedArray objectAtIndex:i]]];
                self.variablesDisplay.text=[self.variablesDisplay.text stringByAppendingString:@"  "];
            }
        }
    }else {
        self.variablesDisplay.text=nil;
    }

    double result = [[self.brain class] runProgram:self.brain.program usingVariableValues:self.testVariableValues];
    
    self.display.text = [NSString stringWithFormat:@"%g", result];
    
}



- (IBAction)decimalPointPressed:(UIButton *)sender {

    NSString *point = [sender currentTitle];
    NSRange range = [self.display.text rangeOfString:@"."];
    if (self.userIsInTheMiddleOfEnteringANumber){
        if (range.location == NSNotFound){
            self.display.text = [self.display.text stringByAppendingString: point];
        }
    }else {
        self.display.text = @"0.";
        self.userIsInTheMiddleOfEnteringANumber = YES;
    }
    
}


- (IBAction)clearPressed {

    [self.brain resetStack];
    self.display.text = @"0";
    self.brainDisplay.text = @"";
    self.variablesDisplay.text = @"";
    self.userIsInTheMiddleOfEnteringANumber = NO;
}

- (IBAction)backspacePressed {

    if (self.userIsInTheMiddleOfEnteringANumber){
        NSString *myString = self.display.text;
        self.display.text = [self.display.text substringToIndex:myString.length -1];

    }

}

- (IBAction)signChangePressed {

    double value = [self.display.text doubleValue]*(-1);
    if (self.userIsInTheMiddleOfEnteringANumber) {
        self.display.text = [NSString stringWithFormat:@"%g", value];
    }else {
    
        self.display.text = [NSString stringWithFormat:@"%g", value];
            [self.brain performSignChange];
        self.brainDisplay.text = [self.brainDisplay.text stringByAppendingString:@"*(-1) ="];
        self.brainDisplay.text = [self.brainDisplay.text stringByAppendingString:self.display.text];
        self.brainDisplay.text = [self.brainDisplay.text stringByAppendingString:@" "];
    }
}



@end
