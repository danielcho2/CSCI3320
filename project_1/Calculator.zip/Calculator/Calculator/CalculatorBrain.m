//
//  CalculatorBrain.m
//  Calculator
//
//  Created by Jenna Tsedensodnom on 2/1/15.
//  Copyright (c) 2015 Jenna Tsedensodnom. All rights reserved.
//

#import "CalculatorBrain.h"

@interface CalculatorBrain()

@property (nonatomic, strong)NSMutableArray *programStack;
@end

@implementation CalculatorBrain
@synthesize programStack = _programStack;

- (NSMutableArray *)programStack
{
    if(_programStack == nil){
        _programStack = [[NSMutableArray alloc] init];
    }
    return _programStack;
}

- (id)program
{
    return [self.programStack copy];
}


- (void)pushOperand:(double)operand
{
    [ self.programStack addObject:[NSNumber numberWithDouble:operand]];
}

- (void)pushVariable:(NSString *)variable{

    [self.programStack addObject:variable];
}




- (double)performOperation:(NSString *)operation
{
   [self.programStack addObject:operation];
   return [[self class] runProgram:self.program];
    
/*
    [self.programStack addObject:operation];
    if (![self.programStack containsObject:@"x"]) {
        return [[self class] runProgram:self.program];
    }
  else return 0;
 */
 }


+ (double)popOperandOfProgramStack:(NSMutableArray *)stack
{
    double result = 0;
    
    id topOfStack = [stack lastObject];
    if (topOfStack) [stack removeLastObject];

    if ([topOfStack isKindOfClass:[NSNumber class]]){
        result = [topOfStack doubleValue];
    } else if ([topOfStack isKindOfClass:[NSString class]]){
        
        NSString * operation = topOfStack;
        if ([operation isEqualToString:@"+"]){
            result = [self popOperandOfProgramStack:stack] + [self popOperandOfProgramStack:stack];
            } else if ([@"*" isEqualToString:operation]) {
                result = [self popOperandOfProgramStack:stack] * [self popOperandOfProgramStack:stack];
            } else if ([operation isEqualToString:@"-"]){
                double subtrahend = [self popOperandOfProgramStack:stack];
                result = [self popOperandOfProgramStack:stack] - subtrahend;
            } else if ([operation isEqualToString:@"/"]) {
                double divisor = [self popOperandOfProgramStack:stack];
                if (divisor) result = [self popOperandOfProgramStack:stack] / divisor;
            } else if ([operation isEqualToString:@"sin"]){
                double value = [self popOperandOfProgramStack:stack]*M_PI/180;
                result = sin(value);
            } else if ([operation isEqualToString:@"cos"]){
                double value = [self popOperandOfProgramStack:stack]*M_PI/180;
                result = cos(value);
            } else if ([operation isEqualToString:@"sqrt"]) {
                result = sqrt([self popOperandOfProgramStack:stack]);
            } else if ([operation isEqualToString:@"π"]){
                result = M_PI;
            }
    
    }
        

    return result;
}



+ (double)runProgram:(id)program
{

    NSMutableArray * stack;
    if ([program isKindOfClass:[NSArray class]]){
        stack = [program mutableCopy];
        
    }
    return [self popOperandOfProgramStack:stack];
}


+ (double)runProgram:(id)program
 usingVariableValues:(NSDictionary *)variableValues;
{
    
    NSMutableArray * stack;
    if ([program isKindOfClass:[NSArray class]]){
        stack = [program mutableCopy];
    }
    for (int i =0; i < [stack count]; i++){
        if ([[stack objectAtIndex:i] isKindOfClass:[NSString class]]&&[[stack objectAtIndex:i] isEqualToString:@"x"]){
            NSString *theValue=[variableValues valueForKey:@"x"];
            NSNumber *value = [NSNumber numberWithDouble:[theValue doubleValue]];
            [stack replaceObjectAtIndex:i withObject:value];
        }
        if ([[stack objectAtIndex:i] isKindOfClass:[NSString class]]&&[[stack objectAtIndex:i] isEqualToString:@"y"]) {
            NSString *theValue=[variableValues valueForKey:@"y"];
            NSNumber *value = [NSNumber numberWithDouble:[theValue doubleValue]];
            [stack replaceObjectAtIndex:i withObject:value];
            
        }
        if ([[stack objectAtIndex:i] isKindOfClass:[NSString class]]&&[[stack objectAtIndex:i] isEqualToString:@"foo"]) {
            NSString *theValue=[variableValues valueForKey:@"foo"];
            NSNumber *value = [NSNumber numberWithDouble:[theValue doubleValue]];
            [stack replaceObjectAtIndex:i withObject:value];

        }
        
        
    }
 
    return [self popOperandOfProgramStack:stack];
}


+ (NSSet *)variablesUsedInProgram:(id)program
{
    NSSet *variablesSetInProgram;
    
    if (!variablesSetInProgram) variablesSetInProgram =[[NSSet alloc]init];
    if ([program containsObject:@"x"]) variablesSetInProgram=[variablesSetInProgram setByAddingObject:@"x"];
    if ([program containsObject:@"y"]) variablesSetInProgram=[variablesSetInProgram setByAddingObject:@"y"];
    if ([program containsObject:@"foo"]) variablesSetInProgram=[variablesSetInProgram setByAddingObject:@"foo"];
    if ([variablesSetInProgram count] ==0) variablesSetInProgram =nil;
    
    return variablesSetInProgram;
}


+ (NSString *)descriptionOfProgram:(id)program
{
  return @"";
}


- (void) resetStack
{
    
    [self.programStack removeAllObjects];
}



- (void) performSignChange{
    
    double value =[[self class] runProgram:self.program]*(-1);
    
    [self pushOperand:value];
}

@end
