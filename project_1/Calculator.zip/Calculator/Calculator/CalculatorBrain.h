//
// CalculatorBrain.h
//  Calculator
//
//  Created by Jenna Tsedensodnom on 2/1/15.
//  Copyright (c) 2015 Jenna Tsedensodnom. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CalculatorBrain : NSObject

- (void)pushOperand:(double)operand;
- (void)pushVariable:(NSString *)variable;

- (double)performOperation:(NSString *)operation;
- (void) resetStack;
- (void) performSignChange;
@ property(nonatomic, readonly) id program;
+ (NSString *)descriptionOfProgram:(id)program;
+ (double)runProgram:(id)program;
+ (NSSet *)variablesUsedInProgram:(id)program;
+ (double)runProgram:(id)program
 usingVariableValues:(NSDictionary *)variableValues;



@end
