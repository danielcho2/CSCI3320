//
//  main.m
//  Calculator
//
//  Created by Jenna Tsedensodnom on 2/1/15.
//  Copyright (c) 2015 Jenna Tsedensodnom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
